// Carpool Sharing App - Backend (Node.js + Express)
// Database: simple JSON file (data/db.json) -> no MongoDB/MySQL install needed.
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

/* ---------------- JSON "database" ---------------- */
const DB_FILE = path.join(__dirname, 'data', 'db.json');
let db = { users: [], rides: [], joinRequests: [], notifications: [], reports: [] };
if (fs.existsSync(DB_FILE)) db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
const save = () => {
  fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
};
const uid = () => crypto.randomUUID();

/* ---------------- Auth helpers (no extra packages) ---------------- */
const SECRET = 'carpool-hackathon-secret';
const hash = (pw, salt = crypto.randomBytes(16).toString('hex')) =>
  salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
const verifyPw = (pw, stored) => hash(pw, stored.split(':')[0]) === stored;
const hmac = (b) => crypto.createHmac('sha256', SECRET).update(b).digest('base64url');
const sign = (payload) => {
  const b = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return b + '.' + hmac(b);
};
const unsign = (t) => {
  const [b, s] = (t || '').split('.');
  if (!b || !s || hmac(b) !== s) return null;
  try {
    const p = JSON.parse(Buffer.from(b, 'base64url').toString());
    return p.exp > Date.now() ? p : null;
  } catch { return null; }
};
const auth = (...roles) => (req, res, next) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const p = unsign(token);
  const u = p && db.users.find((x) => x.userId === p.id);
  if (!u) return res.status(401).json({ error: 'Please login first' });
  if (roles.length && !roles.includes(u.role))
    return res.status(403).json({ error: 'Not allowed for your role' });
  req.user = u;
  next();
};
const safeUser = ({ password, ...rest }) => rest;
const notify = (userId, message) => {
  db.notifications.push({ notificationId: uid(), userId, message, read: false, createdAt: new Date().toISOString() });
};
const withDriver = (r) => {
  const d = db.users.find((u) => u.userId === r.driverId) || {};
  return { ...r, driverName: d.name, driverPhone: d.phone, vehicleDetails: d.vehicleDetails };
};
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });

/* Seed an admin account */
if (!db.users.find((u) => u.role === 'admin')) {
  db.users.push({
    userId: uid(), name: 'Admin', email: 'admin@carpool.com',
    password: hash('admin123'), role: 'admin', phone: '', vehicleDetails: '',
  });
  save();
}

/* ---------------- AUTH ---------------- */
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, role, phone, vehicleDetails } = req.body;
  if (!name || !email || !password) return bad(res, 'Name, email and password are required');
  if (!['driver', 'passenger'].includes(role)) return bad(res, 'Role must be driver or passenger');
  if (password.length < 4) return bad(res, 'Password must be at least 4 characters');
  if (db.users.find((u) => u.email.toLowerCase() === email.toLowerCase()))
    return bad(res, 'Email already registered');
  const user = {
    userId: uid(), name, email, password: hash(password), role,
    phone: phone || '', vehicleDetails: role === 'driver' ? vehicleDetails || '' : '',
  };
  db.users.push(user);
  save();
  res.json({ token: sign({ id: user.userId, exp: Date.now() + 864e5 }), user: safeUser(user) });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.users.find((u) => u.email.toLowerCase() === String(email).toLowerCase());
  if (!user || !verifyPw(password || '', user.password)) return bad(res, 'Invalid email or password', 401);
  res.json({ token: sign({ id: user.userId, exp: Date.now() + 864e5 }), user: safeUser(user) });
});

app.get('/api/auth/me', auth(), (req, res) => res.json(safeUser(req.user)));

/* ---------------- RIDES ---------------- */
app.post('/api/rides', auth('driver'), (req, res) => {
  const { startLocation, destination, date, time, seatsAvailable, costPerSeat } = req.body;
  if (!startLocation || !destination || !date || !time) return bad(res, 'All ride fields are required');
  if (!(Number(seatsAvailable) > 0)) return bad(res, 'Seats must be at least 1');
  if (!(Number(costPerSeat) >= 0)) return bad(res, 'Cost must be 0 or more');
  const ride = {
    rideId: uid(), driverId: req.user.userId, startLocation: startLocation.trim(),
    destination: destination.trim(), date, time,
    seatsAvailable: Number(seatsAvailable), costPerSeat: Number(costPerSeat),
    status: 'Active', createdAt: new Date().toISOString(),
  };
  db.rides.push(ride);
  save();
  res.json(withDriver(ride));
});

app.get('/api/rides', auth(), (req, res) => {
  res.json(db.rides.map(withDriver).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)));
});

// Search: /api/rides/search?from=A&to=B&date=YYYY-MM-DD&minSeats=1&maxCost=500
app.get('/api/rides/search', auth(), (req, res) => {
  const { from = '', to = '', date, minSeats, maxCost } = req.query;
  const has = (v, q) => v.toLowerCase().includes(q.trim().toLowerCase());
  const list = db.rides.filter(
    (r) =>
      r.status === 'Active' && r.seatsAvailable > 0 &&
      has(r.startLocation, from) && has(r.destination, to) &&
      (!date || r.date === date) &&
      (!minSeats || r.seatsAvailable >= Number(minSeats)) &&
      (!maxCost || r.costPerSeat <= Number(maxCost))
  );
  res.json(list.map(withDriver).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)));
});

// My rides: driver -> rides created; passenger -> rides joined (with request status)
app.get('/api/rides/user/:userId', auth(), (req, res) => {
  const u = db.users.find((x) => x.userId === req.params.userId);
  if (!u) return bad(res, 'User not found', 404);
  if (req.user.role !== 'admin' && req.user.userId !== u.userId) return bad(res, 'Not allowed', 403);
  if (u.role === 'driver') return res.json(db.rides.filter((r) => r.driverId === u.userId).map(withDriver));
  const out = db.joinRequests
    .filter((j) => j.passengerId === u.userId)
    .map((j) => {
      const ride = db.rides.find((r) => r.rideId === j.rideId);
      if (!ride) return null;
      const requestStatus = ride.status === 'Cancelled' ? 'Cancelled' : j.status;
      return { ...withDriver(ride), requestId: j.requestId, requestStatus };
    })
    .filter(Boolean);
  res.json(out);
});

app.get('/api/rides/:id', auth(), (req, res) => {
  const r = db.rides.find((x) => x.rideId === req.params.id);
  if (!r) return bad(res, 'Ride not found', 404);
  res.json(withDriver(r));
});

app.put('/api/rides/:id', auth('driver'), (req, res) => {
  const r = db.rides.find((x) => x.rideId === req.params.id);
  if (!r) return bad(res, 'Ride not found', 404);
  if (r.driverId !== req.user.userId) return bad(res, 'Not your ride', 403);
  ['startLocation', 'destination', 'date', 'time'].forEach((k) => req.body[k] && (r[k] = req.body[k]));
  if (req.body.seatsAvailable !== undefined) r.seatsAvailable = Number(req.body.seatsAvailable);
  if (req.body.costPerSeat !== undefined) r.costPerSeat = Number(req.body.costPerSeat);
  save();
  res.json(withDriver(r));
});

app.put('/api/rides/:id/status', auth('driver'), (req, res) => {
  const r = db.rides.find((x) => x.rideId === req.params.id);
  const { status } = req.body;
  if (!r) return bad(res, 'Ride not found', 404);
  if (r.driverId !== req.user.userId) return bad(res, 'Not your ride', 403);
  if (!['Active', 'Completed', 'Cancelled'].includes(status)) return bad(res, 'Invalid status');
  r.status = status;
  const route = `${r.startLocation} → ${r.destination}`;
  db.joinRequests.filter((j) => j.rideId === r.rideId).forEach((j) => {
    if (status === 'Completed' && j.status === 'Approved') {
      j.status = 'Completed';
      notify(j.passengerId, `Your ride ${route} on ${r.date} is completed.`);
    }
    if (status === 'Cancelled' && ['Pending', 'Approved'].includes(j.status)) {
      notify(j.passengerId, `Your ride ${route} on ${r.date} was cancelled by the driver.`);
      if (j.status === 'Pending') j.status = 'Rejected';
    }
  });
  save();
  res.json(withDriver(r));
});

app.delete('/api/rides/:id', auth('driver', 'admin'), (req, res) => {
  const i = db.rides.findIndex((x) => x.rideId === req.params.id);
  if (i < 0) return bad(res, 'Ride not found', 404);
  const r = db.rides[i];
  if (req.user.role === 'driver' && r.driverId !== req.user.userId) return bad(res, 'Not your ride', 403);
  db.joinRequests.filter((j) => j.rideId === r.rideId).forEach((j) =>
    notify(j.passengerId, `Ride ${r.startLocation} → ${r.destination} on ${r.date} was removed.`));
  db.joinRequests = db.joinRequests.filter((j) => j.rideId !== r.rideId);
  db.rides.splice(i, 1);
  save();
  res.json({ ok: true });
});

/* ---------------- JOIN REQUESTS ---------------- */
app.post('/api/join', auth('passenger'), (req, res) => {
  const ride = db.rides.find((r) => r.rideId === req.body.rideId);
  if (!ride) return bad(res, 'Ride not found', 404);
  if (ride.status !== 'Active') return bad(res, 'Ride is not active');
  if (ride.seatsAvailable < 1) return bad(res, 'No seats left');
  const dup = db.joinRequests.find(
    (j) => j.rideId === ride.rideId && j.passengerId === req.user.userId && j.status !== 'Rejected');
  if (dup) return bad(res, 'You already requested this ride');
  const jr = {
    requestId: uid(), rideId: ride.rideId, passengerId: req.user.userId,
    status: 'Pending', createdAt: new Date().toISOString(),
  };
  db.joinRequests.push(jr);
  notify(ride.driverId, `${req.user.name} requested to join ${ride.startLocation} → ${ride.destination}.`);
  save();
  res.json(jr);
});

app.get('/api/join/driver/:driverId', auth('driver'), (req, res) => {
  if (req.params.driverId !== req.user.userId) return bad(res, 'Not allowed', 403);
  const myRides = db.rides.filter((r) => r.driverId === req.user.userId).map((r) => r.rideId);
  const list = db.joinRequests.filter((j) => myRides.includes(j.rideId)).map((j) => {
    const p = db.users.find((u) => u.userId === j.passengerId) || {};
    const r = db.rides.find((x) => x.rideId === j.rideId);
    return { ...j, passengerName: p.name, passengerPhone: p.phone, ride: r };
  });
  res.json(list.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
});

app.put('/api/join/:id', auth('driver'), (req, res) => {
  const jr = db.joinRequests.find((j) => j.requestId === req.params.id);
  if (!jr) return bad(res, 'Request not found', 404);
  const ride = db.rides.find((r) => r.rideId === jr.rideId);
  if (!ride || ride.driverId !== req.user.userId) return bad(res, 'Not your ride', 403);
  const { status } = req.body;
  if (!['Approved', 'Rejected'].includes(status)) return bad(res, 'Status must be Approved or Rejected');
  if (jr.status !== 'Pending') return bad(res, 'Request already handled');
  if (status === 'Approved') {
    if (ride.status !== 'Active') return bad(res, 'Ride is not active');
    if (ride.seatsAvailable < 1) return bad(res, 'No seats left');
    ride.seatsAvailable -= 1;
  }
  jr.status = status;
  notify(jr.passengerId,
    `Your request for ${ride.startLocation} → ${ride.destination} (${ride.date}) was ${status.toLowerCase()}.`);
  save();
  res.json(jr);
});

/* ---------------- NOTIFICATIONS & REPORTS ---------------- */
app.get('/api/notifications', auth(), (req, res) => {
  res.json(db.notifications.filter((n) => n.userId === req.user.userId).reverse());
});
app.put('/api/notifications/read', auth(), (req, res) => {
  db.notifications.filter((n) => n.userId === req.user.userId).forEach((n) => (n.read = true));
  save();
  res.json({ ok: true });
});
app.post('/api/reports', auth(), (req, res) => {
  const { rideId, message } = req.body;
  if (!message) return bad(res, 'Please describe the issue');
  db.reports.push({
    reportId: uid(), rideId: rideId || null, reporterId: req.user.userId,
    reporterName: req.user.name, message, createdAt: new Date().toISOString(),
  });
  save();
  res.json({ ok: true });
});

/* ---------------- ADMIN ---------------- */
app.get('/api/admin/stats', auth('admin'), (req, res) => {
  res.json({
    users: db.users.filter((u) => u.role !== 'admin').length,
    drivers: db.users.filter((u) => u.role === 'driver').length,
    passengers: db.users.filter((u) => u.role === 'passenger').length,
    rides: db.rides.length,
    active: db.rides.filter((r) => r.status === 'Active').length,
    completed: db.rides.filter((r) => r.status === 'Completed').length,
    cancelled: db.rides.filter((r) => r.status === 'Cancelled').length,
    reports: db.reports.length,
  });
});
app.get('/api/admin/users', auth('admin'), (req, res) => res.json(db.users.map(safeUser)));
app.get('/api/admin/reports', auth('admin'), (req, res) => res.json(db.reports.slice().reverse()));

app.listen(3000, () => console.log('Carpool app running at http://localhost:3000'));
