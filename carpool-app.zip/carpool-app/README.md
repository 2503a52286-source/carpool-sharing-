# CarpoolGo - Carpool Sharing App (Problem Statement 23)

Frontend: HTML, CSS, JavaScript | Backend: Node.js + Express | Database: JSON file (no MongoDB needed)

## Run in VS Code
1. Install Node.js (https://nodejs.org) if not installed.
2. Open this folder in VS Code -> Terminal -> New Terminal.
3. Run:
   npm install
   npm start
4. Open http://localhost:3000

Admin login: admin@carpool.com / admin123
Register one Driver and one Passenger (use two browsers or an incognito window) to demo the flow.

## Demo flow (for video)
1. Driver registers -> creates a ride (Hyderabad -> Warangal).
2. Passenger registers -> searches rides -> clicks "Join Ride".
3. Driver -> Join Requests -> Approve (seats decrease by 1).
4. Passenger -> My Rides shows "Approved" + Notifications.
5. Driver marks ride Completed/Cancelled -> passenger gets notified.
6. Admin -> monitor users/rides/reports, remove fraudulent rides.

## API routes
POST /api/auth/register, /api/auth/login | GET /api/auth/me
POST /api/rides (Driver) | GET /api/rides | GET /api/rides/:id
GET /api/rides/search?from=A&to=B | GET /api/rides/user/:userId
PUT /api/rides/:id | PUT /api/rides/:id/status | DELETE /api/rides/:id
POST /api/join (Passenger) | GET /api/join/driver/:driverId | PUT /api/join/:id
GET /api/notifications | PUT /api/notifications/read | POST /api/reports
GET /api/admin/stats | /api/admin/users | /api/admin/reports

## Database (data/db.json, created automatically)
users, rides, joinRequests, notifications, reports
