/* CarpoolGo frontend - plain JavaScript */
let token = localStorage.getItem('token');
let user = null;
let tab = '';

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const badge = (s) => `<span class="badge ${esc(s)}">${esc(s)}</span>`;
const today = () => new Date().toISOString().slice(0, 10);

async function api(url, method = 'GET', body) {
  const res = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function toast(msg, err) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = err ? 'err' : '';
  t.style.display = 'block';
  setTimeout(() => (t.style.display = 'none'), 2800);
}
const run = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };

/* ---------- Start ---------- */
(async function init() {
  if (token) {
    try { user = await api('/api/auth/me'); } catch { token = null; localStorage.removeItem('token'); }
  }
  render();
})();

function logout() {
  localStorage.removeItem('token');
  token = null; user = null; tab = '';
  render();
}

function render() {
  const nav = $('#nav');
  if (!user) { nav.innerHTML = ''; return renderAuth('login'); }
  const tabs = {
    passenger: [['search', 'Search Rides'], ['myrides', 'My Rides'], ['notes', 'Notifications']],
    driver: [['dash', 'Dashboard'], ['requests', 'Join Requests'], ['notes', 'Notifications']],
    admin: [['admin', 'Overview'], ['adminrides', 'Rides'], ['adminusers', 'Users'], ['adminreports', 'Reports']],
  }[user.role];
  if (!tabs.find((t) => t[0] === tab)) tab = tabs[0][0];
  nav.innerHTML =
    `<span>👤 ${esc(user.name)} (${esc(user.role)})</span>` +
    tabs.map((t) => `<button class="${t[0] === tab ? 'active' : ''}" onclick="go('${t[0]}')">${t[1]}</button>`).join('') +
    `<button onclick="logout()">Logout</button>`;
  ({ search: viewSearch, myrides: viewMyRides, notes: viewNotes, dash: viewDash, requests: viewRequests,
     admin: viewAdmin, adminrides: viewAdminRides, adminusers: viewAdminUsers, adminreports: viewAdminReports }[tab])();
}
function go(t) { tab = t; render(); }

/* ---------- Auth ---------- */
function renderAuth(mode) {
  $('#app').innerHTML = `
  <div class="card auth">
    <div class="tabs">
      <button class="${mode === 'login' ? 'active' : ''}" onclick="renderAuth('login')">Login</button>
      <button class="${mode === 'register' ? 'active' : ''}" onclick="renderAuth('register')">Register</button>
    </div>
    ${mode === 'register' ? `
      <div class="field"><label>Name</label><input id="a_name"></div>
      <div class="field"><label>I am a</label>
        <select id="a_role" onchange="$('#drv').classList.toggle('hidden', this.value!=='driver')">
          <option value="passenger">Passenger (Ride Seeker)</option>
          <option value="driver">Driver (Ride Creator)</option>
        </select></div>
      <div class="field"><label>Phone</label><input id="a_phone"></div>
      <div class="field hidden" id="drv"><label>Vehicle details</label><input id="a_veh" placeholder="e.g. Swift - TS 09 AB 1234"></div>` : ''}
    <div class="field"><label>Email</label><input id="a_email" type="email"></div>
    <div class="field"><label>Password</label><input id="a_pass" type="password"></div>
    <button class="btn" style="width:100%" onclick="submitAuth('${mode}')">${mode === 'login' ? 'Login' : 'Create account'}</button>
    ${mode === 'login' ? '<p class="muted" style="margin-top:12px">Admin demo: admin@carpool.com / admin123</p>' : ''}
  </div>`;
}
const submitAuth = run(async (mode) => {
  const body = { email: $('#a_email').value, password: $('#a_pass').value };
  if (mode === 'register') {
    Object.assign(body, { name: $('#a_name').value, role: $('#a_role').value, phone: $('#a_phone').value, vehicleDetails: $('#a_veh').value });
  }
  const d = await api('/api/auth/' + mode, 'POST', body);
  token = d.token; user = d.user;
  localStorage.setItem('token', token);
  tab = '';
  render();
});

/* ---------- Passenger ---------- */
function rideCard(r, withJoin) {
  return `<div class="card ride">
    <div>
      <h3>${esc(r.startLocation)} → ${esc(r.destination)} ${badge(r.status)}</h3>
      <div class="meta">
        📅 ${esc(r.date)} ⏰ ${esc(r.time)}<br>
        🧑 Driver: ${esc(r.driverName)} ${r.driverPhone ? '📞 ' + esc(r.driverPhone) : ''}<br>
        🚘 ${esc(r.vehicleDetails || 'N/A')}<br>
        💺 Seats left: <b>${r.seatsAvailable}</b> &nbsp; 💰 ₹${r.costPerSeat} per seat
      </div>
    </div>
    <div class="row" style="align-self:center">
      ${withJoin ? `<button class="btn" onclick="joinRide('${r.rideId}')">Join Ride</button>` : ''}
      <button class="btn gray small" onclick="reportRide('${r.rideId}')">Report</button>
    </div>
  </div>`;
}

function viewSearch() {
  $('#app').innerHTML = `
  <h2>Search Rides</h2>
  <div class="card">
    <div class="grid">
      <div><label>From</label><input id="s_from" placeholder="Start location"></div>
      <div><label>To</label><input id="s_to" placeholder="Destination"></div>
      <div><label>Date</label><input id="s_date" type="date" min="${today()}"></div>
      <div><label>Min seats</label><input id="s_seats" type="number" min="1"></div>
      <div><label>Max cost/seat</label><input id="s_cost" type="number" min="0"></div>
    </div>
    <div class="row" style="margin-top:12px">
      <button class="btn" onclick="doSearch()">Search</button>
      <button class="btn gray" onclick="viewSearch()">Clear</button>
    </div>
  </div>
  <div id="results"></div>`;
  doSearch();
}
const doSearch = run(async () => {
  const q = new URLSearchParams({
    from: $('#s_from').value, to: $('#s_to').value, date: $('#s_date').value,
    minSeats: $('#s_seats').value, maxCost: $('#s_cost').value,
  });
  const rides = await api('/api/rides/search?' + q);
  $('#results').innerHTML = rides.length
    ? rides.map((r) => rideCard(r, true)).join('')
    : '<div class="card muted">No active rides found. Try different filters.</div>';
});
const joinRide = run(async (rideId) => {
  await api('/api/join', 'POST', { rideId });
  toast('Join request sent! Waiting for driver approval.');
  doSearch();
});
const reportRide = run(async (rideId) => {
  const message = prompt('Describe the issue with this ride:');
  if (!message) return;
  await api('/api/reports', 'POST', { rideId, message });
  toast('Report submitted to admin');
});

const viewMyRides = run(async () => {
  const rows = await api('/api/rides/user/' + user.userId);
  $('#app').innerHTML = `<h2>My Rides</h2><div class="card">${rows.length ? `
    <table><tr><th>Route</th><th>Date</th><th>Time</th><th>Driver</th><th>Cost</th><th>Status</th></tr>
    ${rows.map((r) => `<tr><td>${esc(r.startLocation)} → ${esc(r.destination)}</td><td>${esc(r.date)}</td><td>${esc(r.time)}</td>
      <td>${esc(r.driverName)} ${esc(r.driverPhone || '')}</td><td>₹${r.costPerSeat}</td><td>${badge(r.requestStatus)}</td></tr>`).join('')}
    </table>` : '<p class="muted">You have not joined any rides yet.</p>'}</div>`;
});

/* ---------- Notifications ---------- */
const viewNotes = run(async () => {
  const notes = await api('/api/notifications');
  $('#app').innerHTML = `<h2>Notifications</h2>
    <button class="btn small" onclick="markRead()" style="margin-bottom:12px">Mark all as read</button>
    ${notes.length ? notes.map((n) => `<div class="note ${n.read ? '' : 'unread'}">${esc(n.message)}<br>
      <span class="muted">${new Date(n.createdAt).toLocaleString()}</span></div>`).join('')
      : '<div class="card muted">No notifications yet.</div>'}`;
});
const markRead = run(async () => { await api('/api/notifications/read', 'PUT'); viewNotes(); });

/* ---------- Driver ---------- */
const viewDash = run(async () => {
  const rides = await api('/api/rides/user/' + user.userId);
  $('#app').innerHTML = `
  <h2>Driver Dashboard</h2>
  <div class="card">
    <h3>Create a new ride</h3>
    <div class="grid">
      <div><label>Start location</label><input id="r_from"></div>
      <div><label>Destination</label><input id="r_to"></div>
      <div><label>Date</label><input id="r_date" type="date" min="${today()}"></div>
      <div><label>Time</label><input id="r_time" type="time"></div>
      <div><label>Seats available</label><input id="r_seats" type="number" min="1" value="3"></div>
      <div><label>Cost per seat (₹)</label><input id="r_cost" type="number" min="0" value="50"></div>
    </div>
    <button class="btn" style="margin-top:12px" onclick="createRide()">Create Ride</button>
  </div>
  <h3>My rides</h3>
  ${rides.length ? rides.map((r) => `
    <div class="card ride">
      <div>
        <h3>${esc(r.startLocation)} → ${esc(r.destination)} ${badge(r.status)}</h3>
        <div class="meta">📅 ${esc(r.date)} ⏰ ${esc(r.time)} &nbsp; 💺 ${r.seatsAvailable} seats left &nbsp; 💰 ₹${r.costPerSeat}</div>
      </div>
      <div class="row" style="align-self:center">
        ${r.status === 'Active' ? `
          <button class="btn blue small" onclick="setStatus('${r.rideId}','Completed')">Mark Completed</button>
          <button class="btn red small" onclick="setStatus('${r.rideId}','Cancelled')">Cancel Ride</button>` : ''}
        <button class="btn gray small" onclick="deleteRide('${r.rideId}')">Delete</button>
      </div>
    </div>`).join('') : '<div class="card muted">No rides created yet.</div>'}`;
});
const createRide = run(async () => {
  await api('/api/rides', 'POST', {
    startLocation: $('#r_from').value, destination: $('#r_to').value, date: $('#r_date').value,
    time: $('#r_time').value, seatsAvailable: $('#r_seats').value, costPerSeat: $('#r_cost').value,
  });
  toast('Ride created');
  viewDash();
});
const setStatus = run(async (id, status) => {
  if (!confirm(`Mark this ride as ${status}?`)) return;
  await api(`/api/rides/${id}/status`, 'PUT', { status });
  toast('Ride ' + status.toLowerCase() + '. Passengers notified.');
  viewDash();
});
const deleteRide = run(async (id) => {
  if (!confirm('Delete this ride permanently?')) return;
  await api('/api/rides/' + id, 'DELETE');
  viewDash();
});

const viewRequests = run(async () => {
  const reqs = await api('/api/join/driver/' + user.userId);
  $('#app').innerHTML = `<h2>Join Requests</h2><div class="card">${reqs.length ? `
    <table><tr><th>Passenger</th><th>Phone</th><th>Ride</th><th>Date</th><th>Status</th><th>Action</th></tr>
    ${reqs.map((j) => `<tr><td>${esc(j.passengerName)}</td><td>${esc(j.passengerPhone || '-')}</td>
      <td>${esc(j.ride?.startLocation)} → ${esc(j.ride?.destination)}</td><td>${esc(j.ride?.date)}</td>
      <td>${badge(j.status)}</td>
      <td>${j.status === 'Pending' ? `
        <button class="btn small" onclick="decide('${j.requestId}','Approved')">Approve</button>
        <button class="btn red small" onclick="decide('${j.requestId}','Rejected')">Reject</button>` : '-'}</td></tr>`).join('')}
    </table>` : '<p class="muted">No join requests yet.</p>'}</div>`;
});
const decide = run(async (id, status) => {
  await api('/api/join/' + id, 'PUT', { status });
  toast('Request ' + status.toLowerCase());
  viewRequests();
});

/* ---------- Admin ---------- */
const viewAdmin = run(async () => {
  const s = await api('/api/admin/stats');
  const box = (n, l) => `<div class="card stat"><b>${s[n]}</b>${l}</div>`;
  $('#app').innerHTML = `<h2>Admin Overview</h2><div class="grid">
    ${box('users', 'Users')}${box('drivers', 'Drivers')}${box('passengers', 'Passengers')}${box('rides', 'Total rides')}
    ${box('active', 'Active')}${box('completed', 'Completed')}${box('cancelled', 'Cancelled')}${box('reports', 'Reported issues')}</div>`;
});
const viewAdminRides = run(async () => {
  const rides = await api('/api/rides');
  $('#app').innerHTML = `<h2>All Rides</h2><div class="card">${rides.length ? `
    <table><tr><th>Route</th><th>Date</th><th>Driver</th><th>Seats</th><th>Cost</th><th>Status</th><th></th></tr>
    ${rides.map((r) => `<tr><td>${esc(r.startLocation)} → ${esc(r.destination)}</td><td>${esc(r.date)} ${esc(r.time)}</td>
      <td>${esc(r.driverName)}</td><td>${r.seatsAvailable}</td><td>₹${r.costPerSeat}</td><td>${badge(r.status)}</td>
      <td><button class="btn red small" onclick="adminDelete('${r.rideId}')">Remove</button></td></tr>`).join('')}
    </table>` : '<p class="muted">No rides.</p>'}</div>`;
});
const adminDelete = run(async (id) => {
  if (!confirm('Remove this ride (inactive/fraudulent)?')) return;
  await api('/api/rides/' + id, 'DELETE');
  viewAdminRides();
});
const viewAdminUsers = run(async () => {
  const users = await api('/api/admin/users');
  $('#app').innerHTML = `<h2>Users</h2><div class="card"><table>
    <tr><th>Name</th><th>Email</th><th>Role</th><th>Phone</th><th>Vehicle</th></tr>
    ${users.map((u) => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${esc(u.role)}</td>
      <td>${esc(u.phone || '-')}</td><td>${esc(u.vehicleDetails || '-')}</td></tr>`).join('')}</table></div>`;
});
const viewAdminReports = run(async () => {
  const reps = await api('/api/admin/reports');
  $('#app').innerHTML = `<h2>Reported Issues</h2>${reps.length ? reps.map((r) => `
    <div class="note"><b>${esc(r.reporterName)}</b>: ${esc(r.message)}<br>
    <span class="muted">Ride: ${esc(r.rideId || 'N/A')} · ${new Date(r.createdAt).toLocaleString()}</span></div>`).join('')
    : '<div class="card muted">No reported issues.</div>'}`;
});
